package net.strinka.strinkout

enum class ActivityType {
    TRANSITION, EXERCISE, REST
}